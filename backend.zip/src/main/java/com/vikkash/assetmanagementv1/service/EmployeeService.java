package com.vikkash.assetmanagementv1.service;

import com.vikkash.assetmanagementv1.dto.ChangePasswordRequest;
import com.vikkash.assetmanagementv1.dto.EmployeeCreateRequest;
import com.vikkash.assetmanagementv1.dto.EmployeeLoginRequest;
import com.vikkash.assetmanagementv1.dto.EmployeeSeparationDetailDTO;
import com.vikkash.assetmanagementv1.dto.EmployeeUpdateRequest;
import com.vikkash.assetmanagementv1.dto.InitiateSeparationRequest;
import com.vikkash.assetmanagementv1.dto.LoginResponse;
import com.vikkash.assetmanagementv1.dto.SeparationRemarksRequest;
import com.vikkash.assetmanagementv1.entity.Asset;
import com.vikkash.assetmanagementv1.entity.Employee;
import com.vikkash.assetmanagementv1.entity.EmploymentStatus;
import com.vikkash.assetmanagementv1.exception.DuplicateResourceException;
import com.vikkash.assetmanagementv1.exception.InvalidCredentialsException;
import com.vikkash.assetmanagementv1.exception.PendingAssetReturnException;
import com.vikkash.assetmanagementv1.exception.ResourceNotFoundException;
import com.vikkash.assetmanagementv1.repository.AssetRepository;
import com.vikkash.assetmanagementv1.repository.EmployeeRepository;
import com.vikkash.assetmanagementv1.security.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    private static final Logger log = LoggerFactory.getLogger(EmployeeService.class);

    /** Organization-wide default password for all new employees. */
    public static final String DEFAULT_PASSWORD = "Haoda@321";

    private final EmployeeRepository employeeRepository;
    private final AssetRepository    assetRepository;
    private final PasswordEncoder    passwordEncoder;
    private final JwtUtil            jwtUtil;
    private final AuditLogService    auditLogService;
    private final SeparationNotificationService separationNotificationService;

    public EmployeeService(EmployeeRepository employeeRepository,
                           AssetRepository assetRepository,
                           PasswordEncoder passwordEncoder,
                           JwtUtil jwtUtil,
                           AuditLogService auditLogService,
                           SeparationNotificationService separationNotificationService) {
        this.employeeRepository = employeeRepository;
        this.assetRepository    = assetRepository;
        this.passwordEncoder    = passwordEncoder;
        this.jwtUtil            = jwtUtil;
        this.auditLogService    = auditLogService;
        this.separationNotificationService = separationNotificationService;
    }

    // ── Authentication ─────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public LoginResponse login(EmployeeLoginRequest request) {

        String empId = request.getEmployeeId().trim().toUpperCase();

        log.info("Login attempt for {}", empId);

        Employee employee = employeeRepository.findByEmployeeId(empId)
                .orElseThrow(() -> {
                    log.error("Employee NOT FOUND: {}", empId);
                    return new InvalidCredentialsException("Invalid Employee ID or password");
                });

        log.info("Employee found: {}", employee.getEmployeeId());

        boolean match = passwordEncoder.matches(request.getPassword(), employee.getPassword());

        log.info("Password match = {}", match);

        if (!match) {
            throw new InvalidCredentialsException("Invalid Employee ID or password");
        }

        String token = jwtUtil.generateToken(employee.getEmployeeId(), "EMPLOYEE");

        return LoginResponse.forEmployee(token, employee);
    }

    @Transactional
    public void changePassword(ChangePasswordRequest request) {
        String empId = request.getEmployeeId().trim().toUpperCase();

        Employee employee = employeeRepository.findByEmployeeId(empId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + empId));

        if (!passwordEncoder.matches(request.getCurrentPassword(), employee.getPassword())) {
            throw new InvalidCredentialsException("Current password is incorrect");
        }

        if (passwordEncoder.matches(request.getNewPassword(), employee.getPassword())) {
            throw new IllegalArgumentException("New password must be different from the current password");
        }

        employee.setPassword(passwordEncoder.encode(request.getNewPassword()));
        employee.setMustChangePassword(false);
        employeeRepository.save(employee);
        log.info("Password changed for employee: {}", empId);
        auditLogService.record("EMPLOYEE", empId, "PASSWORD_CHANGED", "Employee changed their own password");
    }

    // ── CRUD ───────────────────────────────────────────────────────────────

    @Transactional
    public Employee createEmployee(EmployeeCreateRequest request) {
        String empId = request.getEmployeeId().trim().toUpperCase();

        if (employeeRepository.existsByEmployeeId(empId)) {
            throw new DuplicateResourceException("Employee ID already exists: " + empId);
        }
        if (request.getEmail() != null && !request.getEmail().isBlank()
                && employeeRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already in use: " + request.getEmail());
        }

        Employee employee = new Employee();
        employee.setEmployeeId(empId);
        employee.setEmployeeName(request.getEmployeeName());
        employee.setEmail(request.getEmail());
        employee.setDepartment(request.getDepartment());
        employee.setDesignation(request.getDesignation());
        employee.setLocation(request.getLocation());
        employee.setJoiningDate(request.getJoiningDate());
        employee.setRole("EMPLOYEE");
        employee.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        employee.setMustChangePassword(true);  // force change on first login

        log.info("Created employee: {}", empId);
        Employee saved = employeeRepository.save(employee);
        auditLogService.record("EMPLOYEE", empId, "CREATED",
                "Created employee " + employee.getEmployeeName() + " (" + empId + ")");
        return saved;
    }

    @Transactional(readOnly = true)
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Employee getByEmployeeId(String employeeId) {
        return employeeRepository.findByEmployeeId(employeeId.trim().toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
    }

    @Transactional
    public Employee updateEmployee(Long id, EmployeeUpdateRequest request) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));

        if (request.getEmail() != null && !request.getEmail().isBlank()
                && !request.getEmail().equalsIgnoreCase(employee.getEmail())
                && employeeRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already in use: " + request.getEmail());
        }

        String oldEmployeeId = employee.getEmployeeId(); // capture BEFORE overwriting
        String newEmployeeId = request.getEmployeeId().trim().toUpperCase();

        // Guard against renaming into an ID that's already taken by someone else.
        if (!newEmployeeId.equalsIgnoreCase(oldEmployeeId)
                && employeeRepository.existsByEmployeeId(newEmployeeId)) {
            throw new DuplicateResourceException("Employee ID already in use: " + newEmployeeId);
        }

        employee.setEmployeeId(newEmployeeId);
        employee.setEmployeeName(request.getEmployeeName());
        employee.setEmail(request.getEmail());
        employee.setDepartment(request.getDepartment());
        employee.setDesignation(request.getDesignation());
        employee.setLocation(request.getLocation());
        employee.setJoiningDate(request.getJoiningDate());

        Employee saved = employeeRepository.save(employee);

        // CASCADE: if the employeeId actually changed, every asset that was
        // linked to the OLD id must be repointed at the NEW one — otherwise
        // those assets silently orphan (they'll still show the employee's
        // name on the Assets page, but vanish from that employee's "View
        // Assets" panel, since that lookup matches strictly on employeeId).
        if (oldEmployeeId != null && !oldEmployeeId.isBlank()
                && !newEmployeeId.equalsIgnoreCase(oldEmployeeId)) {
            List<Asset> ownedAssets = assetRepository.findByEmployeeId(oldEmployeeId);
            for (Asset asset : ownedAssets) {
                asset.setEmployeeId(newEmployeeId);
            }
            if (!ownedAssets.isEmpty()) {
                assetRepository.saveAll(ownedAssets);
                log.info("Employee ID changed {} -> {}: relinked {} asset(s) to the new ID.",
                        oldEmployeeId, newEmployeeId, ownedAssets.size());
            }
        }

        // CASCADE: the Employee table is the single source of truth for name,
        // role, and — critically — location. Whenever any of those change
        // here (not just on an employeeId rename), every asset currently
        // assigned to this person must be updated to match, or the Employees
        // page and the Asset Inventory page will disagree about where that
        // person (and their equipment) is located until the asset happens to
        // be reassigned again.
        List<Asset> currentlyAssigned = assetRepository.findByEmployeeId(newEmployeeId);
        String syncedRole = (saved.getDesignation() != null && !saved.getDesignation().isBlank())
                ? saved.getDesignation()
                : saved.getRole();
        boolean anyChanged = false;
        for (Asset asset : currentlyAssigned) {
            boolean changed = false;
            if (!java.util.Objects.equals(asset.getEmployeeName(), saved.getEmployeeName())) {
                asset.setEmployeeName(saved.getEmployeeName());
                changed = true;
            }
            if (!java.util.Objects.equals(asset.getEmployeeRole(), syncedRole)) {
                asset.setEmployeeRole(syncedRole);
                changed = true;
            }
            if (!java.util.Objects.equals(asset.getLocation(), saved.getLocation())) {
                asset.setLocation(saved.getLocation());
                changed = true;
            }
            anyChanged = anyChanged || changed;
        }
        if (!currentlyAssigned.isEmpty()) {
            assetRepository.saveAll(currentlyAssigned);
        }
        if (anyChanged) {
            log.info("Employee {} updated: synced name/role/location onto {} assigned asset(s).",
                    newEmployeeId, currentlyAssigned.size());
            auditLogService.record("EMPLOYEE", newEmployeeId, "SYNCED_ASSETS",
                    "Propagated updated name/role/location to " + currentlyAssigned.size()
                            + " asset(s) assigned to " + saved.getEmployeeName());
        }

        auditLogService.record("EMPLOYEE", newEmployeeId, "UPDATED", "Updated employee " + saved.getEmployeeName() + " (" + newEmployeeId + ")");
        return saved;
    }

    @Transactional
    public void deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        log.warn("Deleting employee id={}", id);
        employeeRepository.deleteById(id);
        auditLogService.record("EMPLOYEE", employee.getEmployeeId(), "DELETED",
                "Deleted employee " + employee.getEmployeeName() + " (" + employee.getEmployeeId() + ")");
    }

    /**
     * Admin-triggered password reset. Sets the password back to the org default
     * and forces the employee to change it on their next login.
     *
     * BUG FIX: previously set mustChangePassword=false — incorrect.
     * After a reset the employee MUST be forced to change their password.
     */
    @Transactional
    public void resetToDefaultPassword(String employeeId) {
        Employee employee = getByEmployeeId(employeeId);
        employee.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        employee.setMustChangePassword(true);   // ← was incorrectly false
        employeeRepository.save(employee);
        log.info("Password reset to default for employee: {}", employeeId);
        auditLogService.record("EMPLOYEE", employeeId, "PASSWORD_RESET", "Admin reset password to default");
    }

    /** Returns all assets currently assigned to this employee. */
    @Transactional(readOnly = true)
    public List<Asset> getAssetsForEmployee(String employeeId) {
        return assetRepository.findByEmployeeId(employeeId.trim().toUpperCase());
    }

    // ═════════════════════════════════════════════════════════════════════
    //  EMPLOYEE SEPARATION / RESIGNATION WORKFLOW
    //  Active → Notice Period → Exit Clearance → Assets Returned → Resigned
    //  Employees are NEVER deleted as part of this flow — only their
    //  employmentStatus and separation fields change, so full employment
    //  history remains queryable forever.
    // ═════════════════════════════════════════════════════════════════════

    /** Full separation detail for the Employee Separation Modal / Separation History section. */
    @Transactional(readOnly = true)
    public EmployeeSeparationDetailDTO getSeparationDetail(String employeeId) {
        Employee employee = getByEmployeeId(employeeId);
        List<Asset> assigned = assetRepository.findByEmployeeId(employee.getEmployeeId()).stream()
                .filter(a -> "Assigned".equals(a.getAssetStatus()))
                .collect(Collectors.toList());
        List<Asset> returned = assetRepository.findByLastEmployeeIdAndEmployeeIdIsNull(employee.getEmployeeId());
        return EmployeeSeparationDetailDTO.from(employee, assigned, returned);
    }

    /** Step 1: Active → Notice Period. Kicks off the resignation and notifies HR. */
    @Transactional
    public EmployeeSeparationDetailDTO initiateSeparation(String employeeId, InitiateSeparationRequest request) {
        Employee employee = getByEmployeeId(employeeId);

        if (EmploymentStatus.RESIGNED.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException(
                    "This employee is already Resigned. Reactivate them first if you need to restart separation.");
        }
        if (!EmploymentStatus.ACTIVE.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException(
                    "A separation is already in progress for this employee (status: " + employee.getEmploymentStatus() + ").");
        }

        employee.setEmploymentStatus(EmploymentStatus.NOTICE_PERIOD);
        employee.setNoticeStartDate(request.getNoticeStartDate());
        employee.setLastWorkingDate(request.getLastWorkingDate());
        employee.setResignationReason(request.getResignationReason());
        employee.setNoticePeriodDays(request.getNoticePeriodDays());
        employee.setSeparationRemarks(request.getRemarks());
        employee.setExitClearanceStatus(EmploymentStatus.CLEARANCE_PENDING);
        employee.setClearanceCompletionDate(null);
        employee.setResignedDate(null);

        Employee saved = employeeRepository.save(employee);
        auditLogService.record("EMPLOYEE", saved.getEmployeeId(), "SEPARATION_INITIATED",
                "Resignation started for " + saved.getEmployeeName() + " — reason: " + request.getResignationReason()
                        + ", last working date: " + request.getLastWorkingDate());
        separationNotificationService.notifySeparationStarted(saved);

        return getSeparationDetail(saved.getEmployeeId());
    }

    /** Step 2: Notice Period → Exit Clearance. Notifies IT to collect any still-assigned assets. */
    @Transactional
    public EmployeeSeparationDetailDTO moveToExitClearance(String employeeId, SeparationRemarksRequest request) {
        Employee employee = getByEmployeeId(employeeId);

        if (!EmploymentStatus.NOTICE_PERIOD.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException(
                    "Employee must be in Notice Period to move to Exit Clearance (current status: "
                            + employee.getEmploymentStatus() + ").");
        }

        employee.setEmploymentStatus(EmploymentStatus.EXIT_CLEARANCE);
        if (request != null && request.getRemarks() != null && !request.getRemarks().isBlank()) {
            employee.setSeparationRemarks(request.getRemarks());
        }
        Employee saved = employeeRepository.save(employee);

        long pendingAssets = assetRepository.countByAssetStatusAndEmployeeId("Assigned", saved.getEmployeeId());
        auditLogService.record("EMPLOYEE", saved.getEmployeeId(), "SEPARATION_EXIT_CLEARANCE",
                "Moved to Exit Clearance for " + saved.getEmployeeName() + " — " + pendingAssets + " asset(s) pending return");
        separationNotificationService.notifyAssetCollectionRequired(saved, (int) pendingAssets);

        return getSeparationDetail(saved.getEmployeeId());
    }

    /**
     * Step 3 (validation gate): attempts to finalize the resignation. BLOCKED with a
     * {@link PendingAssetReturnException} listing every still-assigned asset if any
     * remain — per spec, resignation cannot complete until all assets are returned.
     * On success, moves the employee through Assets Returned → Resigned in one step
     * (both flags reflect reality the instant the asset check passes) and notifies Admin.
     */
    @Transactional
    public EmployeeSeparationDetailDTO completeResignation(String employeeId, SeparationRemarksRequest request) {
        Employee employee = getByEmployeeId(employeeId);

        if (EmploymentStatus.RESIGNED.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException("This employee is already marked Resigned.");
        }
        if (EmploymentStatus.ACTIVE.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException("Separation has not been initiated for this employee yet.");
        }

        List<Asset> stillAssigned = assetRepository.findByEmployeeId(employee.getEmployeeId()).stream()
                .filter(a -> "Assigned".equals(a.getAssetStatus()))
                .collect(Collectors.toList());
        if (!stillAssigned.isEmpty()) {
            throw new PendingAssetReturnException(stillAssigned);
        }

        String today = LocalDate.now().toString();
        employee.setEmploymentStatus(EmploymentStatus.ASSETS_RETURNED);
        employee.setExitClearanceStatus(EmploymentStatus.CLEARANCE_COMPLETED);
        employee.setClearanceCompletionDate(today);
        if (request != null && request.getRemarks() != null && !request.getRemarks().isBlank()) {
            employee.setSeparationRemarks(request.getRemarks());
        }
        employeeRepository.save(employee);
        separationNotificationService.notifyClearanceComplete(employee);

        employee.setEmploymentStatus(EmploymentStatus.RESIGNED);
        employee.setResignedDate(today);
        Employee saved = employeeRepository.save(employee);

        auditLogService.record("EMPLOYEE", saved.getEmployeeId(), "SEPARATION_COMPLETED",
                "Resignation finalized for " + saved.getEmployeeName() + " as of " + today
                        + " — all assets confirmed returned.");
        separationNotificationService.notifyResignationFinalized(saved);

        return getSeparationDetail(saved.getEmployeeId());
    }

    /** Cancels an in-progress separation and restores the employee to Active (e.g. resignation withdrawn). */
    @Transactional
    public EmployeeSeparationDetailDTO cancelSeparation(String employeeId, SeparationRemarksRequest request) {
        Employee employee = getByEmployeeId(employeeId);

        if (EmploymentStatus.ACTIVE.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException("This employee is already Active — there is no separation to cancel.");
        }
        if (EmploymentStatus.RESIGNED.equals(employee.getEmploymentStatus())) {
            throw new IllegalArgumentException(
                    "This employee is already Resigned. Use Reactivate instead if they are rejoining.");
        }

        employee.setEmploymentStatus(EmploymentStatus.ACTIVE);
        employee.setNoticeStartDate(null);
        employee.setLastWorkingDate(null);
        employee.setResignationReason(null);
        employee.setNoticePeriodDays(null);
        employee.setExitClearanceStatus(EmploymentStatus.CLEARANCE_PENDING);
        employee.setClearanceCompletionDate(null);
        employee.setResignedDate(null);
        employee.setSeparationRemarks(request != null ? request.getRemarks() : null);

        Employee saved = employeeRepository.save(employee);
        auditLogService.record("EMPLOYEE", saved.getEmployeeId(), "SEPARATION_CANCELLED",
                "Separation cancelled for " + saved.getEmployeeName() + " — restored to Active");

        return getSeparationDetail(saved.getEmployeeId());
    }

    /** Dashboard widgets: Notice Period / Pending Exit Clearance / Resigned This Month / Pending Asset Returns. */
    @Transactional(readOnly = true)
    public Map<String, Long> getSeparationDashboardStats() {
        YearMonth thisMonth = YearMonth.now();
        String monthStart = thisMonth.atDay(1).toString();
        String monthEnd = thisMonth.atEndOfMonth().toString();

        return Map.of(
                "noticePeriod", employeeRepository.countByEmploymentStatus(EmploymentStatus.NOTICE_PERIOD),
                "pendingExitClearance", employeeRepository.countPendingExitClearance(),
                "resignedThisMonth", employeeRepository.countResignedBetween(monthStart, monthEnd),
                "pendingAssetReturns", assetRepository.countPendingAssetReturnsAcrossSeparatingEmployees()
        );
    }

    /** Every employee currently anywhere in the separation pipeline (or already Resigned) — feeds the Employee Exit Report. */
    @Transactional(readOnly = true)
    public List<Employee> getAllInSeparation() {
        return employeeRepository.findAllInSeparation();
    }
}
